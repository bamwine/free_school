<div class="main-content" style="min-height: 1711px;">
<div class="row">
<div class="col-md-12 col-sm-12 clearfix" style="text-align:center;">
<h2 style="font-weight:200; margin:0px; color: #FF9900">OPTIMUM LINKUP SCHOOL SYSTEMS</h2>
</div>

<div class="col-md-12 col-sm-12 clearfix ">
<ul class="list-inline links-list pull-left">

<li class="dropdown language-selector">
<strong style="color:#FF0000">Running Session:&nbsp;2016-2017</strong>
<a href="#" class="dropdown-toggle" data-toggle="dropdown" data-close-others="true">
<i class="entypo-user"></i>admin </a>
<ul class="dropdown-menu pull-left">
<li>
<a href="https://www.optimumlinkup.com.ng/software/index.php?admin/manage_profile">
<i class="entypo-info"></i>
<span>Edit Profile</span>
</a>
</li>
<li>
<a href="https://www.optimumlinkup.com.ng/software/index.php?admin/manage_profile">
<i class="entypo-key"></i>
<span>change password</span>
</a>
</li>
</ul>
</li>
</ul>
<ul class="list-inline links-list pull-right">


<li>
<a href="https://www.optimumlinkup.com.ng/software/index.php?login/logout">
Log Out <i class="entypo-logout right"></i>
</a>
</li>
</ul>
</div>
</div>
<hr style="margin-top:0px;">
<h3 style="">
<i class="entypo-right-circled"></i>
system settings </h3>
<hr>
<div class="row">
<form action="https://www.optimumlinkup.com.ng/software/index.php?admin/system_settings/do_update" class="form-horizontal form-groups-bordered validate" target="_top" method="post" accept-charset="utf-8" novalidate="novalidate">
<div class="col-md-6">
<div class="panel panel-gradient">
<div class="panel-heading">
<div class="panel-title">
system settings </div>
</div>
<div class="panel-body">
<div class="form-group">
<label class="col-sm-3 control-label">system name</label>
<div class="col-sm-9">
<input type="text" class="form-control" name="system_name" value="OPTIMUM LINKUP SCHOOL SYSTEMS">
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">system title</label>
<div class="col-sm-9">
<input type="text" class="form-control" name="system_title" value="OPTIMUM SCHOOL SYSTEM">
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">address</label>
<div class="col-sm-9">
<input type="text" class="form-control" name="address" value="546, SILICON VALLEY TORONTO, CANADA">
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">phone</label>
<div class="col-sm-9">
<input type="text" class="form-control" name="phone" value="+1564783934">
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">paypal email</label>
<div class="col-sm-9">
<input type="text" class="form-control" name="paypal_email" value="optimumproblemsolver@gmail.com">
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">currency</label>
<div class="col-sm-9">
<input type="text" class="form-control" name="currency" value="$">
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">system email</label>
<div class="col-sm-9">
<input type="text" class="form-control" name="system_email" value="optimumproblemsolver@gmail.com">
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">language</label>
<div class="col-sm-9">
<select name="language" class="form-control ">
<option value="english" selected=""> english </option>
<option value="bengali"> bengali </option>
<option value="spanish"> spanish </option>
<option value="arabic"> arabic </option>
<option value="dutch"> dutch </option>
<option value="russian"> russian </option>
<option value="chinese"> chinese </option>
<option value="turkish"> turkish </option>
<option value="portuguese"> portuguese </option>
<option value="hungarian"> hungarian </option>
<option value="french"> french </option>
<option value="greek"> greek </option>
<option value="german"> german </option>
<option value="italian"> italian </option>
<option value="thai"> thai </option>
<option value="urdu"> urdu </option>
<option value="hindi"> hindi </option>
<option value="latin"> latin </option>
<option value="indonesian"> indonesian </option>
<option value="japanese"> japanese </option>
<option value="korean"> korean </option>
<option value="Kiswahili"> Kiswahili </option>
<option value="español"> español </option>
<option value="amharic"> amharic </option>
<option value="Afaan Oromo"> Afaan Oromo </option>
<option value="khmer"> khmer </option>
<option value="kurdish"> kurdish </option>
<option value="Georgian"> Georgian </option>
<option value="Pashtu"> Pashtu </option>
</select>
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">Text Align</label>
<div class="col-sm-9">
<div class="select2-container form-control select2 visible" id="s2id_autogen1"><a href="javascript:void(0)" onclick="return false;" class="select2-choice" tabindex="-1">   <span class="select2-chosen"> left-to-right</span><abbr class="select2-search-choice-close"></abbr>   <span class="select2-arrow"><b></b></span></a><input class="select2-focusser select2-offscreen" type="text" id="s2id_autogen2"><div class="select2-drop select2-display-none select2-with-searchbox">   <div class="select2-search">       <input type="text" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" class="select2-input">   </div>   <ul class="select2-results" tabindex="5000" style="overflow: hidden; outline: none;">   </ul><div id="ascrail2000" class="nicescroll-rails" style="padding-right: 3px; width: 10px; z-index: 9999; position: absolute; top: 0px; left: -10px; height: 0px; cursor: default; display: none;"><div style="position: relative; top: 0px; float: right; width: 5px; height: 0px; border: 1px solid rgb(204, 204, 204); border-radius: 5px; background-color: rgb(212, 212, 212); background-clip: padding-box;"></div></div><div id="ascrail2000-hr" class="nicescroll-rails" style="height: 7px; z-index: 9999; top: -7px; left: 0px; position: absolute; cursor: default; display: none;"><div style="position: relative; top: 0px; height: 5px; width: 0px; border: 1px solid rgb(204, 204, 204); border-radius: 5px; background-color: rgb(212, 212, 212); background-clip: padding-box;"></div></div></div></div><select name="text_align" class="form-control select2 select2-offscreen visible" tabindex="-1">
<option value="left-to-right" selected=""> left-to-right</option>
<option value="right-to-left"> right-to-left</option>
</select>
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">Running Session</label>
<div class="col-sm-9">
<select name="running_session" class="form-control ">
<option value="">2016-2017</option>
<option value="2016-2017">2016-2017</option>
<option value="2017-2018">2017-2018</option>
<option value="2018-2019">2018-2019</option>
<option value="2019-2020">2019-2020</option>
<option value="2020-2021">2020-2021</option>
<option value="2021-2022">2021-2022</option>
<option value="2022-2023">2022-2023</option>
<option value="2023-2024">2023-2024</option>
<option value="2024-2025">2024-2025</option>
<option value="2025-2026">2025-2026</option>
<option value="2026-2027">2026-2027</option>
<option value="2027-2028">2027-2028</option>
<option value="2028-2029">2028-2029</option>
<option value="2029-2030">2029-2030</option>
<option value="2017">2017</option>
</select>
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label">System Footer</label>
<div class="col-sm-9">
<input type="text" class="form-control" name="system_footer" value="Ã‚Â© 2017 Optimum Linkup School Management System. Developed by 	<a href=" https:="" optimumlinkup.com.ng"="">Optimum Linkup Universal Concepts Version 5.0"&gt;
</div>
</div>
<br>
<div class="alert alert-info">This is a demo version, some features has been disabled. You can not change the system settings detials</div>

</div>
</div>
<div class="panel panel-gradient" data-collapsed="0">
<div class="panel-heading">
<div class="panel-title">
Update Product </div>
</div>
<div class="panel-body form-horizontal form-groups-bordered">
<form action="https://www.optimumlinkup.com.ng/software/index.php?updater/update" class="form-horizontal form-groups-bordered" enctype="multipart/form-data" method="post" accept-charset="utf-8">
<div class="form-group">
<label class="col-sm-3 control-label">File</label>
<div class="col-sm-5">
<a class="file-input-wrapper btn form-control file2 inline btn btn-primary"><i class="glyphicon glyphicon-file"></i> Browse<input type="file" name="file_name" class="form-control file2 inline btn btn-primary" data-label="<i class='glyphicon glyphicon-file'></i> Browse" style="left: -2.375px; top: 15px;"></a>
</div>
</div>
<br>
<div class="alert alert-info">This is a demo version, some features has been disabled. You can not change the system detials</div>
</form> </div>
</div>
</div></form>
<div class="col-md-6">
<div class="panel panel-gradient">
<div class="panel-heading">
<div class="panel-title">
Theme Settings </div>
</div>
<div class="panel-body">
<div class="gallery-env">
<div class="col-sm-4">
<article class="album">
<header>
<a href="#" id="default">
<img src="assets/images/skins/default.png" style="background-color: black; opacity: 0.3;">
</a>
<a href="#" class="album-options" id="default">
<i class="entypo-check"></i>
Default </a>
</header>
</article>
</div>
<div class="col-sm-4">
<article class="album">
<header>
<a href="#" id="black">
<img src="assets/images/skins/black.png">
</a>
<a href="#" class="album-options" id="black">
<i class="entypo-check"></i>
Select Theme </a>
</header>
</article>
</div>
<div class="col-sm-4">
<article class="album">
<header>
<a href="#" id="blue">
<img src="assets/images/skins/blue.png">
</a>
 <a href="#" class="album-options" id="blue">
<i class="entypo-check"></i>
Select Theme </a>
</header>
</article>
</div>
<div class="col-sm-4">
<article class="album">
<header>
<a href="#" id="cafe">
<img src="assets/images/skins/cafe.png">
</a>
<a href="#" class="album-options" id="cafe">
<i class="entypo-check"></i>
Select Theme </a>
</header>
</article>
</div>
<div class="col-sm-4">
<article class="album">
<header>
<a href="#" id="green">
<img src="assets/images/skins/green.png">
</a>
<a href="#" class="album-options" id="green">
<i class="entypo-check"></i>
Select Theme </a>
</header>
</article>
</div>
<div class="col-sm-4">
<article class="album">
<header>
<a href="#" id="purple">
<img src="assets/images/skins/purple.png">
</a>
<a href="#" class="album-options" id="purple">
<i class="entypo-check"></i>
Select Theme </a>
</header>
</article>
</div>
<div class="col-sm-4">
<article class="album">
<header>
<a href="#" id="red">
<img src="assets/images/skins/red.png">
</a>
<a href="#" class="album-options" id="red">
<i class="entypo-check"></i>
Select Theme </a>
</header>
</article>
</div>
<div class="col-sm-4">
<article class="album">
<header>
<a href="#" id="white">
<img src="assets/images/skins/white.png">
</a>
<a href="#" class="album-options" id="white">
<i class="entypo-check"></i>
Select Theme </a>
</header>
</article>
</div>
<div class="col-sm-4">
<article class="album">
<header>
<a href="#" id="yellow">
<img src="assets/images/skins/yellow.png">
</a>
<a href="#" class="album-options" id="yellow">
<i class="entypo-check"></i>
Select Theme </a>
</header>
</article>
</div>
</div>
<center>
<div class="label label-primary" style="font-size: 12px;">
<i class="entypo-check"></i> Select A Theme To Make Changes </div>
</center>
</div>
</div>
<form action="https://www.optimumlinkup.com.ng/software/index.php?admin/system_settings/upload_logo" class="form-horizontal form-groups-bordered validate" target="_top" enctype="multipart/form-data" method="post" accept-charset="utf-8" novalidate="novalidate">
<div class="panel panel-gradient">
<div class="panel-heading">
<div class="panel-title">
Upload Logo </div>
</div>
<div class="panel-body">
<div class="form-group">
<label for="field-1" class="col-sm-3 control-label">photo</label>
<div class="col-sm-9">
<div class="fileinput fileinput-new" data-provides="fileinput"><input type="hidden">
<div class="fileinput-new thumbnail" style="width: 100px; height: 100px;" data-trigger="fileinput">
<img src="https://www.optimumlinkup.com.ng/software/uploads/logo.png" alt="...">
</div>
<div class="fileinput-preview fileinput-exists thumbnail" style="max-width: 200px; max-height: 150px; line-height: 6px;"></div>
<div>
<span class="btn btn-white btn-file">
<span class="fileinput-new">Select image</span>
<span class="fileinput-exists">Change</span>
<input type="file" name="userfile" accept="image/*">
</span>
<a href="#" class="btn btn-orange fileinput-exists" data-dismiss="fileinput">Remove</a>
</div>
</div>
</div>
</div>
<br>
<div class="alert alert-info">This is a demo version, some features has been disabled. You can not change the system image </div>
</div>
</div>
</form>
</div>
</div>
<script type="text/javascript">
    $(".gallery-env").on('click', 'a', function () {
        skin = this.id;
        $.ajax({
            url: 'https://www.optimumlinkup.com.ng/software/index.php?admin/system_settings/change_skin/'+ skin,
            success: window.location = 'https://www.optimumlinkup.com.ng/software/index.php?admin/system_settings/'
        });
});
</script>

<footer class="main" align="center" style="color:#FF0000">Ã‚Â© 2017 Optimum Linkup School Management System. Developed by <a href="https://optimumlinkup.com.ng">Optimum Linkup Universal Concepts</a> Version 5.0</footer>
</div>