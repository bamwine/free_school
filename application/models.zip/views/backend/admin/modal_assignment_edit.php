<div class="row">
<div class="col-md-12">
<div class="panel panel-primary" data-collapsed="0">
<div class="panel-heading">
<div class="panel-title">
<h3>Edit Assignment</h3>
</div>
</div>
<div class="panel-body">
<form role="form" class="form-horizontal form-groups-bordered" action="https://www.optimumlinkup.com.ng/software/index.php?admin/assignment/do_update/1" method="post" enctype="multipart/form-data">
<div class="form-group">
<label for="field-1" class="col-sm-3 control-label">date</label>
<div class="col-sm-7">
<div class="date-and-time">
<input type="text" name="timestamp" class="form-control datepicker" data-format="D, dd MM yyyy" placeholder="date here" value="">
</div>
</div>
</div>
<div class="form-group">
<label for="field-1" class="col-sm-3 control-label">title</label>
<div class="col-sm-5">
<input type="text" name="title" class="form-control" id="field-1" value="TRUE LOVE STORY">
</div>
</div>
<div class="form-group">
<label for="field-ta" class="col-sm-3 control-label">description</label>
<div class="col-sm-9">
<textarea name="description" class="form-control wysihtml5" data-stylesheet-url="https://www.optimumlinkup.com.ng/software/assets/css/wysihtml5-color.css" id="field-ta">GO TO GOOGLE AND BROWSE FOR INFORMATION ABOUT TITANIC</textarea>
</div>
</div>
<div class="form-group">
<label for="field-ta" class="col-sm-3 control-label">class</label>
<div class="col-sm-5">
<select name="class_id" class="form-control">
<option value="">select class</option>
<option value="2" selected="">
KG </option>
<option value="3">
Primary One </option>
<option value="4">
PRIMARY THREE </option>
<option value="5">
Grade 11 </option>
<option value="6">
class </option>
<option value="7">
10th </option>
</select>
</div>
</div>
<div class="col-sm-3 control-label col-sm-offset-1">
<input type="submit" class="btn btn-success" value="Update">
</div>
</form>
</div>
</div>
</div>
</div>