<div class="panel panel-gradient">
<div class="panel-heading">
<div class="panel-title">
Assignment Information Page </div>
</div>
<div class="table-responsive">
<br>
&nbsp;&nbsp;&nbsp;&nbsp;<button onclick="showAjaxModal('https://www.optimumlinkup.com.ng/software/index.php?modal/popup/modal_assignment_add');" class="btn btn-primary">
Add Assignment</button>
<br><br>
<table class="table table-bordered table-striped datatable" id="table-2">
<thead>
<tr>
<th>#</th>
<th>date</th>
<th>title</th>
<th>description</th>
<th>class</th>
<th>Download</th>
<th>options</th>
</tr>
</thead>
<tbody>
<tr>
<td>1</td>
<td>Wed, 12 July 2017</td>
<td>TRUE LOVE STORY</td>
<td>GO TO GOOGLE AND BROWSE FOR INFORMATION ABOUT TITANIC</td>
<td>
KG </td>
<td>
<a href="https://www.optimumlinkup.com.ng/software/uploads/assignment/Email.docx" class="btn btn-blue btn-icon icon-left">
<i class="entypo-download"></i>
Download
</a>
</td>
<td>
<a onclick="showAjaxModal('https://www.optimumlinkup.com.ng/software/index.php?modal/popup/modal_assignment_edit/1');" class="btn btn-info btn-sm btn-icon icon-left">
<i class="entypo-pencil"></i>
Edit
</a>
<a href="https://www.optimumlinkup.com.ng/software/index.php?admin/assignment/delete/1" class="btn btn-danger btn-sm btn-icon icon-left" onclick="return confirm('Are you sure to delete?');">
<i class="entypo-cancel"></i>
Delete
</a>
</td>
</tr>
</tbody>
</table>
</div>
</div>