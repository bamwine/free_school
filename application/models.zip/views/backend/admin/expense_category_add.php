<div class="col-md-12">
<div class="panel panel-primary" data-collapsed="0">
<div class="panel-heading">
<div class="panel-title">
<i class="entypo-plus-circled"></i>
Add Expense Category </div>
</div>
<div class="panel-body">
<form action="index.php?admin/expense_category/create/" class="form-horizontal form-groups-bordered validate" enctype="multipart/form-data" method="post" accept-charset="utf-8" novalidate="novalidate">
<div class="form-group">
<label for="field-1" class="col-sm-3 control-label">name</label>
<div class="col-sm-6">
<input type="text" class="form-control" name="name" data-validate="required" data-message-required="Value Required" value="" autofocus="">
</div>
</div>
<div class="form-group">
<div class="col-sm-offset-3 col-sm-5">
<button type="submit" class="btn btn-info">Add Expense Category</button>
</div>
</div>
</form>
 </div>
 
</div>

</div>

