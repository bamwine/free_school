<!-- Footer -->
<footer class="main">
	&copy; 2015	<a href=" http://bamwine.byethost14.com " > BSigned </a>
                                        
<!--	<strong> smart School</strong>. 
    A Product of BSigned company </footer>  -->
