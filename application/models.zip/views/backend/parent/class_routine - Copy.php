<div class="panel panel-gradient">
<div class="panel-heading">
<div class="panel-title">
Class Routine Information </div>
</div>
<div class="table-responsive">
<div class="tab-content">

<div class="tab-pane active" id="list">
<div class="panel-group joined" id="accordion-test-2">
<div class="panel panel-default">
<div class="panel-heading">
<h4 class="panel-title">
<a data-toggle="collapse" data-parent="#accordion-test-2" href="#collapse2">
<i class="entypo-rss"></i> Class KG </a>
</h4>
</div>
<div id="collapse2" class="panel-collapse collapse in">
<div class="panel-body">
<table cellpadding="0" cellspacing="0" border="0" class="table table-bordered">
<tbody>
<tr class="gradeA">
<td width="100">SUNDAY</td>
<td>
</td>
</tr>
<tr class="gradeA">
<td width="100">MONDAY</td>
<td>
<button class="btn btn-primary">
Economics (8:35-9:35) </button>
 </td>
</tr>
<tr class="gradeA">
<td width="100">TUESDAY</td>
<td>
</td>
</tr>
<tr class="gradeA">
<td width="100">WEDNESDAY</td>
<td>
</td>
</tr>
<tr class="gradeA">
<td width="100">THURSDAY</td>
<td>
</td>
</tr>
<tr class="gradeA">
<td width="100">FRIDAY</td>
<td>
</td>
</tr>
<tr class="gradeA">
<td width="100">SATURDAY</td>
<td>
</td>
</tr>
</tbody>
</table>
</div>
</div>
</div>
<div class="panel panel-default">
<div class="panel-heading">
<h4 class="panel-title">
<a data-toggle="collapse" data-parent="#accordion-test-2" href="#collapse3">
<i class="entypo-rss"></i> Class Primary One </a>
</h4>
</div>
<div id="collapse3" class="panel-collapse collapse ">
<div class="panel-body">
<table cellpadding="0" cellspacing="0" border="0" class="table table-bordered">
<tbody>
<tr class="gradeA">
<td width="100">SUNDAY</td>
<td>
</td>
</tr>
<tr class="gradeA">
 <td width="100">MONDAY</td>
<td>
</td>
</tr>
<tr class="gradeA">
<td width="100">TUESDAY</td>
<td>
</td>
</tr>
<tr class="gradeA">
<td width="100">WEDNESDAY</td>
<td>
</td>
</tr>
<tr class="gradeA">
<td width="100">THURSDAY</td>
<td>
</td>
</tr>
<tr class="gradeA">
<td width="100">FRIDAY</td>
<td>
</td>
</tr>
<tr class="gradeA">
<td width="100">SATURDAY</td>
<td>
</td>
</tr>
</tbody>
</table>
</div>
</div>
</div>
<div class="panel panel-default">
<div class="panel-heading">
<h4 class="panel-title">
<a data-toggle="collapse" data-parent="#accordion-test-2" href="#collapse4">
<i class="entypo-rss"></i> Class PRIMARY THREE </a>
</h4>
</div>
<div id="collapse4" class="panel-collapse collapse ">
<div class="panel-body">
<table cellpadding="0" cellspacing="0" border="0" class="table table-bordered">
<tbody>
<tr class="gradeA">
<td width="100">SUNDAY</td>
<td>
</td>
</tr>
 <tr class="gradeA">
<td width="100">MONDAY</td>
<td>
</td>
</tr>
<tr class="gradeA">
<td width="100">TUESDAY</td>
<td>
</td>
</tr>
<tr class="gradeA">
<td width="100">WEDNESDAY</td>
<td>
</td>
</tr>
<tr class="gradeA">
<td width="100">THURSDAY</td>
<td>
</td>
</tr>
<tr class="gradeA">
<td width="100">FRIDAY</td>
<td>
</td>
</tr>
<tr class="gradeA">
<td width="100">SATURDAY</td>
<td>
</td>
</tr>
</tbody>
</table>
</div>
</div>
</div>
<div class="panel panel-default">
<div class="panel-heading">
<h4 class="panel-title">
<a data-toggle="collapse" data-parent="#accordion-test-2" href="#collapse5">
<i class="entypo-rss"></i> Class Grade 11 </a>
</h4>
</div>
<div id="collapse5" class="panel-collapse collapse ">
<div class="panel-body">
<table cellpadding="0" cellspacing="0" border="0" class="table table-bordered">
<tbody>
<tr class="gradeA">
<td width="100">SUNDAY</td>
<td>

</td>
</tr>
<tr class="gradeA">
<td width="100">MONDAY</td>
<td>
</td>
</tr>
<tr class="gradeA">
<td width="100">TUESDAY</td>
<td>
</td>
</tr>
<tr class="gradeA">
<td width="100">WEDNESDAY</td>
<td>
</td>
</tr>
<tr class="gradeA">
<td width="100">THURSDAY</td>
<td>
</td>
</tr>
<tr class="gradeA">
<td width="100">FRIDAY</td>
<td>
</td>
</tr>
<tr class="gradeA">
<td width="100">SATURDAY</td>
<td>
</td>
</tr>
</tbody>
</table>
</div>
</div>
</div>
<div class="panel panel-default">
<div class="panel-heading">
<h4 class="panel-title">
<a data-toggle="collapse" data-parent="#accordion-test-2" href="#collapse6">
<i class="entypo-rss"></i> Class class </a>
</h4>
</div>
<div id="collapse6" class="panel-collapse collapse ">
<div class="panel-body">
<table cellpadding="0" cellspacing="0" border="0" class="table table-bordered">
<tbody>
<tr class="gradeA">
 <td width="100">SUNDAY</td>
<td>
</td>
</tr>
<tr class="gradeA">
<td width="100">MONDAY</td>
<td>
</td>
</tr>
<tr class="gradeA">
<td width="100">TUESDAY</td>
<td>
</td>
</tr>
<tr class="gradeA">
<td width="100">WEDNESDAY</td>
<td>
</td>
</tr>
<tr class="gradeA">
<td width="100">THURSDAY</td>
<td>
</td>
</tr>
<tr class="gradeA">
<td width="100">FRIDAY</td>
<td>
</td>
</tr>
<tr class="gradeA">
<td width="100">SATURDAY</td>
<td>
</td>
</tr>
</tbody>
</table>
</div>
</div>
</div>
</div>
</div>

</div>
</div>
</div>