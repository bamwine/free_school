<div class="mail-body">

<div class="mail-header">

<h3 class="mail-title">
Messages </h3>

<form method="get" role="form" class="mail-search">
<div class="input-group">
<input type="text" class="form-control" name="s" placeholder="Search for mail...">
<div class="input-group-addon">
<i class="entypo-search"></i>
</div>
</div>
</form>
</div>
<div style="width:100%; text-align:center;padding:100px;color:#aaa;">
<img src="https://www.optimumlinkup.com.ng/software/assets/images/inbox.png" width="70">
<br><br>
<div>
Select a message to read
</div>
</div> </div>