<div class="panel panel-gradient">
<div class="panel-heading">
<div class="panel-title">
<a data-toggle="collapse" data-parent="#accordion-test-2" href="#collapse2">
<i class="entypo-rss"></i> Class 2 </a>

</div>
</div>
<div class="panel-body table-responsive">
<table cellpadding="0" cellspacing="0" border="0" class="table table-bordered">
<tbody>
<tr class="gradeA">
<td width="100">SUNDAY</td>
<td>
</td>
</tr>
<tr class="gradeA">
<td width="100">MONDAY</td>
<td>
<button class="btn btn-primary">
Economics (8:35-9:35) </button>
</td>
</tr>
<tr class="gradeA">
<td width="100">TUESDAY</td>
<td>
</td>
</tr>
 <tr class="gradeA">
<td width="100">WEDNESDAY</td>
<td>
</td>
</tr>
<tr class="gradeA">
<td width="100">THURSDAY</td>
<td>
</td>
</tr>
<tr class="gradeA">
<td width="100">FRIDAY</td>
<td>
</td>
</tr>
<tr class="gradeA">
<td width="100">SATURDAY</td>
<td>
</td>
</tr>
</tbody>
</table>
</div>

</div>