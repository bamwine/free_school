<div class="mail-body">

<div class="mail-info">
<div class="mail-sender " style="padding:7px;">
<a href="#" class="dropdown-toggle" data-toggle="dropdown">
<img src="https://www.optimumlinkup.com.ng/software/uploads/admin_image/1.jpg" class="img-circle" width="30">
<span>Mr. Admin</span>
</a>
</div>
<div class="mail-date" style="padding:7px;">
29 Jul, 2017
</div>
</div>
<div class="mail-text">
<p> hello</p>
</div>
<div class="mail-info">
<div class="mail-sender " style="padding:7px;">
<a href="#" class="dropdown-toggle" data-toggle="dropdown">
<img src="https://www.optimumlinkup.com.ng/software/uploads/admin_image/1.jpg" class="img-circle" width="30">
<span>Mr. Admin</span>
</a>
</div>
<div class="mail-date" style="padding:7px;">
25 Sep, 2017
</div>
</div>
<div class="mail-text">
<p> hello</p>
</div>
<div class="mail-info">
<div class="mail-sender " style="padding:7px;">
<a href="#" class="dropdown-toggle" data-toggle="dropdown">
<img src="https://www.optimumlinkup.com.ng/software/uploads/admin_image/1.jpg" class="img-circle" width="30">
<span>Mr. Admin</span>
</a>
</div>
<div class="mail-date" style="padding:7px;">
13 Oct, 2017
</div>
</div>
<div class="mail-text">
<p> hello</p>
</div>
<form action="https://www.optimumlinkup.com.ng/software/index.php?teacher/message/send_reply/2acef1850bd586c" enctype="multipart/form-data" method="post" accept-charset="utf-8">
<div class="mail-reply">
<div class="compose-message-editor">
<textarea row="5" class="form-control wysihtml5" data-stylesheet-url="assets/css/wysihtml5-color.css" name="message" placeholder="Reply Message" id="sample_wysiwyg"></textarea>
</div>
<br>
<button type="submit" class="btn btn-success btn-icon pull-right">
Send <i class="entypo-mail"></i>
</button>
<br><br>
</div>
</form> </div>